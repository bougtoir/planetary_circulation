# HARD-CODE AND RESULT-PROVENANCE AUDIT
Date: 2026-10-17 (UTC). Scope: all scripts in `analysis/scripts/`, all manuscript-facing
artifacts, packaged `tables/`/`figures/`/`manuscript/` copies, submission zips.

## 1. Scripts inspected
`build_data.py` (canonical rows), `derive_matrices.py` (matrices + coverage_stats),
`analyze.py` (persistence spectrum, spread, MC, PCA, LOO, networks, Spearman, energy CSV),
`figures_1_5_6.py` (Figs 1,5,6 — Fig 2–4 generated inside analyze.py), `build_manuscript.py`
(main docx, supplement, highlights, cover letter), `build_inline.py` (inline reading copy).

## 2. Search patterns used
Literal scans for every reported value: `92.9|94.6|53/56|52/56|32 of 56|32/56|0.56|56%|17%|
15%|44%|95%|46|66|4.1|3.5|1.2|2.0|0.91|0.78|0.44|0.99|-0.18|-0.33|0.22|0.08|0.68|0.61|0.42|
0.85|0.09|0.22|4–7|four bodies|4 components`; keyword scans `manual|hardcod|override|
final number|use old|stale`; file-name scans `api_|asynchronous_|_revised|submission_final|_old|_v1|_v2|backup|final2`.

## 3. Scientific-result literals found

| Literal | Location (pre-fix) | Classification | Resolution |
|---|---|---|---|
| "32 of 56" quantitative cells | build_manuscript.py §2; DATA_QC.md; earlier reports | **MAJOR — untraceable/stale**: canonical data yields 10 cells with a numeric estimate or measured zero | FIXED: `quant_cells` computed in derive_matrices.py → coverage_stats.json; Methods now f-string; DATA_QC.md corrected |
| "PC1 = 46–66%" | §3.2 | MODERATE (verified value, hardcoded) | FIXED: computed from pca_loo.csv |
| "15%" (PC3) | §3.2 | MODERATE | FIXED: `{pc3}` |
| "~56%" | §4 Discussion | MODERATE | FIXED: `{pc1}` |
| "~44%" (4 sites: abstract, §4, conclusions, cover letter; + highlights) | MODERATE | FIXED: `{offaxis}` = 100−pc1 |
| "~0.09" (Mars dynamo frac), "~0.22" (Mercury E1 frac) | §3.3 | MODERATE (correct values, hardcoded) | FIXED: read from persistence_spectrum.csv |
| "4 (Moon) to 7 (Earth, Mars, Europa, Titan), with Venus and Io at 6 and Mercury at 5" | §3.4 | MODERATE | FIXED: built from network_metrics |
| "4 components" (Moon, Mercury) | §3.4 | MODERATE | FIXED: from network_metrics n_components |
| "four bodies" (E4 absences) | §3.1/§3.4 | MODERATE | FIXED: computed from master CSV |
| "95% cell coverage" | §5 Conclusions | **MAJOR — stale pre-Io-fix value** (94.6→95; canonical is 92.9) | FIXED: `{abc_pct}` → renders 93% |
| Fig. 6 `dom` dict | figures_1_5_6.py | MODERATE — driver classification duplicated in a second file with divergent labels (e.g. "internal (dynamo)" vs canonical "internal (dynamo persists)") | FIXED: reads `dom_driver` from energy_architecture.csv |
| "56" total cells; "seven"/"eight" ontology; n=8 | multiple | MINOR — fixed ontology counts | kept (legitimate) |
| "~4.1 Ga", "~3.5 Ga", "1.2–2.0 Ga", "~4 Gyr" | abstract/§3.3/§4/cover letter | REVIEW — literature-cited canonical *inputs* (Mars dynamo_off (4.1,4.1,4.14); Mercury E1 end 3.5; Moon E1 1.2–2.0), verified identical to canonical rows | kept as input literals; flagged for awareness |
| Io 9.3e13 W / ~10^14 W; Earth ~47 TW; ~1 t/s; ~3 kg/s; 4.96e5 km3/yr; 1.34e9 km3 | §3.5, cover letter | REVIEW — canonical input data values (master CSV estimate cells), verified | kept as input literals |
| Reference entries, seeds (rng=7), plot dims, colors | — | MINOR | kept |

## 4. Manual overrides
None found — no "manual fix"/"override" comments, no result constants in functions,
no silent exception → substituted result paths.

## 5. Stale-output dependencies
See STALE_RESULT_AUDIT.md. All stale submission-facing copies archived to
`archive/pre_hostile_review/`; packaged fig PNGs refreshed from canonical; deleted-API
tables removed.

## 6. Single-source-of-truth chain
RAW inputs (literature-cited rows in `build_data.py` + `dynamo_off` cessation specs in
`analyze.py`) → `data/processed/` (master CSV, matrices, coverage_stats, body_attributes)
→ `analysis/derived/` (persistence spectrum/spread, MC, PCA outputs, network metrics,
null correlations, energy architecture, analysis_summary.json) → `analysis/figures/` +
`tables/`/`figures/` copies → `manuscript/*.docx|txt` via `build_manuscript.py`
(all reportable values now f-string-injected) → `submission/` zip.
Machine-readable map: `reports/result_traceability.csv`.

## 7. One-run regeneration
PASS — see REGENERATION_CHECK.md (data+derived byte-identical; docx payload-identical).

## 8. Unresolved concerns
- Cessation-age literals (~4.1 Ga, ~3.5 Ga, 1.2–2.0 Ga) live in prose AND in
  `dynamo_off`/EDGE_META inputs — verified equal; converting them to f-strings would
  require parsing citation-carrying notes, judged over-engineering for a Letter.
- Two measured-zero cells (Moon E1, Mercury E1 estimate=0) count as quantitative;
  `quant_cells=10` is the strict count.
- fig2/3/4 are generated inside analyze.py (not figures_1_5_6.py) — a layout quirk,
  not a provenance risk; outputs verified canonical.

## 9. Final judgment: **PASS**
After fixes, every reportable scientific result in the submission-facing artifacts is
generated from canonical pipeline outputs; the one untraceable literal ("32 of 56") and
one stale literal ("95%") were corrected at the source of truth, not patched in prose.
