# EPSL FINAL READINESS — post hostile-review + targeted revision
Date: 2026-10-17 (UTC).

## Gate classification: **A — EPSL READY**

All fatal/major correctable defects found in the hostile review are fixed on the canonical
tree; remaining majors are documented limitations inherent to an n=8 comparative pilot.

## What changed vs the previous package
- Persistence: one statistic everywhere (max−min over dated cessations + censored cells);
  Monte Carlo now samples that statistic; IQR "API" removed; Venus's inferred dynamo loss
  excluded from the statistic but shown (grey-dashed) in Fig. 4.
- Ontology: E4 = subsurface *volatile* reservoir only; Io's melt layer moved to E1; Io E4
  structurally absent (4 absent bodies: Venus, Moon, Mercury, Io).
- Energy: `dom_driver` (dominant circulation-driving energy source) replaces the stale
  `dom=stellar` column; calibrated "more informative in this pilot" wording.
- Numbers: coverage 92.9% (was 94.6%); process counts 4–7 with Io at 6; age ρ −0.18,
  mass ρ 0.22 (descriptive); all f-string-driven from derived outputs.

## Verified
- Full pipeline reran clean: build_data → derive_matrices → analyze → figures →
  build_manuscript → soffice PDF conversion.
- Data–Text–Figure audit: PASS on every key number.
- Public repo bougtoir/planetary_circulation: public + populated + was in sync before this
  revision. **ACTION DONE: sync branch `devin/1790413216-planetary-circulation` was pushed
  2026-10-17; the cron sync workflow mirrors it to the public repo automatically.**

## Remaining author-side items (unchanged)
- Title-page `[TO COMPLETE]` placeholders: authors, affiliations, corresponding author,
  CRediT, acknowledgements; `[VERIFY]` competing-interests line.
- Optional graphical abstract; Editorial Manager submission (article type: Letter).

## Package
`submission/EPSL_submission_package_FINAL_HOSTILE_REVIEWED.zip` — manuscript docx/pdf,
inline reading copy, supplement, highlights, cover letter, figures, tables (canonical
derived CSVs incl. spread_montecarlo.csv), data, reports.

## HARD-CODE / SINGLE-SOURCE-OF-TRUTH AUDIT: PASS

(2026-10-17 pass — see HARDCODE_AUDIT.md, result_traceability.csv, REGENERATION_CHECK.md,
STALE_RESULT_AUDIT.md.) Two MAJOR defects found and fixed at source: untraceable
"32 of 56" quantitative cells → computed 10; stale "95% cell coverage" in Conclusions →
dynamic 93%. Ten verified-but-hardcoded literals converted to generated values; Fig. 6
driver labels now read canonical `dom_driver`; stale pre-review artifacts archived to
`archive/pre_hostile_review/`; one-run regeneration is byte-/payload-identical.
Remaining literals are canonical input values (cessation ages, quantitative anchors) or
fixed ontology constants — documented, verified.

New package: `submission/EPSL_submission_package_FINAL_HARDCODE_AUDITED.zip`.
