# HOSTILE REVIEW SYNTHESIS
Date: 2026-10-17 (UTC). Inputs: HOSTILE_EDITOR_REVIEW, HOSTILE_REVIEWER1_METHODS,
HOSTILE_REVIEWER2_PLANETARY, NOVELTY_HOSTILE_AUDIT, CITATION_ECOLOGY,
DATA_TEXT_FIGURE_AUDIT.

## 1. Fatal issues
- **Persistence metric contradiction (Issue 1)** — main text range-spread vs supplement IQR
  "API" giving Mars/Mercury ≈ 0; plus silently omitted Venus spread (0.99 > Mars) making
  "Mars/Mercury most spread" false as computed. **FIXED:** single statistic (max−min over
  dated cessations + censored cells), MC on the same statistic, IQR/API removed, dated-rule
  excludes the inferred Venus dynamo loss (kept in Fig. 4, flagged).

## 2. Major issues
- **E4 ontology inconsistency (Issue 2)** — Io's silicate partial-melt layer coded under a
  volatile-liquid node shared with oceans/brines. **FIXED:** E4 restricted to volatile
  reservoirs; Io melt layer → E1 evidence; Io E4 → structurally absent; counts, networks,
  coverage, text regenerated (Io 7→6; coverage 94.6%→92.9%).
- **Energy-source ambiguity (Issue 3)** — packaged CSV's `dom=stellar` for all bodies vs
  "organizes better" claim. **FIXED:** stale packaged table replaced; `dom_driver`
  = dominant circulation-driving energy source; wording calibrated.
- **"Current" timescale ambiguity (R2#14), geological vs direct evidence mixing (R2#15)** —
  irreducible; mitigated by separate persistence axis and evidence-type flags. **Retained
  as stated limitation.**

## 3. Moderate issues (selected)
PCA-on-ordinal + median imputation (now explicit), n=8, E5/E3/E7 overlap, E7 breadth,
cherry-picking, Enceladus exclusion, contested plumes/cryovolcanism — each either fixed,
calibrated, or documented as limitation (see reviewer tables).

## 4. Issues fixed
Metric harmonization; Venus selective-reporting; Io E4; stale packaged energy table;
dynamic coverage/correlation values; supplement S4 rewritten; Fig. 4 inferred-row legend.

## 5. Issues retained as limitations
n=8; ordinal PCA (exploratory label); "current" definition across timescales;
observational asymmetry (Apollo-era Moon data vs contested Europa plumes); no Enceladus/
Ganymede/Triton; qualitative-matrix dependency of E7.

## 6. Exact effect on conclusions
Headline results unchanged: PC1 ≈ 56% + ~44% residual; spreads 0.91/0.78/0.44 for
Mars/Mercury/Moon; asynchronous cessation supported. Process counts shift (Io 7→6) with
no change in range (4–7). Null correlations weaker but direction-identical and still
non-ordering (age ρ −0.18, mass ρ 0.22, n.s.) — H4 survives with slightly softer numbers.
Coverage 94.6% → 92.9% (gate still GO).

## 7. Do H1–H4 survive?
- H1 (one axis adequate?): YES — answered in the middle, dominant axis + real off-axis structure.
- H2 (asynchronous persistence?): YES — now on a single, dated-evidence statistic with MC bands.
- H3 (connectivity differences?): YES — component structure differs beyond process presence.
- H4 (irreducible to age/mass?): YES — correlations remain non-ordering; energy-driver
  architecture is the more informative descriptor in the pilot.

## 8. Augmentation-gap paragraph
Survives — Discussion-only, unchanged, not expanded.

## 9. Is EPSL still the best target?
YES (B → A after fixes). The Letter's single take-home result, common measurement basis,
and honest pilot framing fit EPSL; the framework-vs-catalogue risk is mitigated by the
explicit H-tests.

## 10. Fallback if desk-rejected
**JGR: Planets** — no restructuring needed (per EPSL_FIT_AUDIT); secondary: Icarus.

## 11. HARD-CODE AND RESULT-PROVENANCE REVIEW (2026-10-17 audit)

Standing questions answered (see reports/HARDCODE_AUDIT.md + result_traceability.csv):

1. **Are any reported scientific results hard-coded?** Two problematic literals were found
   and fixed: "32 of 56" quantitative cells (untraceable — canonical count is 10; **MAJOR**)
   and "95% cell coverage" in Conclusions (stale pre-Io-fix value; **MAJOR**). Both now
   computed from coverage_stats.json. Ten further verified-correct literals (LOO range,
   off-axis variance, spread fractions, process counts, component counts, E4-absence count)
   were converted to generated values (**MODERATE** class, eliminated).
2. **Any figures on manually entered result arrays?** Fig. 6's driver labels were an
   independent hardcoded dict duplicating `dom_driver`; it now reads the canonical CSV.
   All figure data otherwise reads `data/processed` + `analysis/derived` only.
3. **Any manuscript numbers copied from stale outputs?** The "95%" and "32" instances
   above; also stale packaged PNG copies and pre-revision docx/zips — archived under
   `archive/pre_hostile_review/`.
4. **Single canonical result source?** Yes: build_data → derived matrices → derived
   statistics → figures/tables → docx (all reportable numbers f-string-injected).
5. **Can all major numbers be regenerated?** Yes — deterministic pipeline
   (REGENERATION_CHECK: byte-/payload-identical).
6. **Did the ontology/method revision leave old numbers downstream?** None after this
   pass; the two remaining stale literals were exactly that and are fixed.
7. **Captions/highlights/cover letter synchronized?** Yes — verified after dynamication.
8. **One-run regeneration without manual numeric editing?** Yes — PASS.

Residual REVIEW items (documented, accepted): cessation-age prose literals (~4.1, ~3.5,
1.2–2.0 Ga) and quantitative anchors are canonical *input* literals, verified against the
master CSV; fixed-ontology constants (8 bodies, 7 classes, 56 cells, n=8) are legitimate.
