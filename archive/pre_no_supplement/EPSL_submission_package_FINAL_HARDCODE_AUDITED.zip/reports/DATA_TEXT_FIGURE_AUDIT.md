# DATA–TEXT–FIGURE CONSISTENCY AUDIT (post-revision)
Date: 2026-10-17 (UTC). Source of truth: `analysis/derived/` + `data/processed/` regenerated
this session (build_data → derive_matrices → analyze → figures_1_5_6 → build_manuscript).

## Key numbers — canonical vs manuscript

| Quantity | Canonical | Manuscript | Status |
|---|---|---|---|
| Evaluable cells (tier A–C) | 52/56 = 92.9% (D tier now 4: Venus, Moon, Mercury, Io E4) | Abstract + §3.1 read from coverage_stats.json (f-strings) | PASS |
| Quantitative cells | **10/56** (corrected — "32" was untraceable legacy; hard-code audit) | §2 "10 of 56" now computed | PASS |
| PC1/PC2/PC3 | 56.4% / 16.8% / 15.2% | "~56% / ~17% / ~15%"; LOO PC1 46.5–66.3% → "46–66%" | PASS |
| Persistence spread (dated rule) | Mars 0.91, Mercury 0.78, Moon 0.44; all others 0.00 | §3.3 identical values, f-string driven | PASS |
| Spread Monte Carlo | Mars 0.92 [0.91,0.92]; Mercury 0.83 [0.78,0.88]; Moon 0.50 [0.32,0.75] | §3.3 text + Supplement S4 (same statistic now) | PASS |
| Supported process counts | Earth 7, Venus 6, Mars 7, Moon 4, Mercury 5, Io 6, Europa 7, Titan 7 | §3.4 "4 (Moon) to 7 (Earth, Mars, Europa, Titan), Venus and Io at 6, Mercury at 5" | PASS |
| Network components | Moon & Mercury 4 comp; Venus & Io 3 comp (6 nodes); Earth/Mars/Europa/Titan 3 comp (7 nodes) | §3.4 wording | PASS |
| Age Spearman | ρ = −0.18, p = 0.68 | dynamic f-strings (abstract, §3.6, highlights) | PASS (was −0.33/0.42 pre-Io-fix) |
| Mass Spearman | ρ = 0.22, p = 0.61 | dynamic f-strings | PASS (was 0.08/0.85) |
| Quantitative anchors | Io 9.3e13 W; Earth 47 TW; escape fluxes unchanged | §3.5 unchanged, verified | PASS |
| Coverage gate | GO (92.9% ≥ 70%, 8/8 bodies ≥4 evaluable) | — | PASS |

## Downstream trace of the three corrections

- **E4 ontology (Io):** master CSV row rewritten (structurally_absent, D/O0);
  measurement_dictionary, activity/tier/persistence matrices, coverage stats, Fig. 2 cell
  (now "—"), Fig. 5 Io panel (6 nodes, no SL edge, "6/7"), network_metrics, Spearman nulls,
  §3.1/§3.4 text, highlights, abstract — all regenerated. PCA unchanged (Io's E4 was probable
  = 3; imputed column median is also 3) — verified PC1/PC2 identical.
- **Persistence statistic:** IQR/API outputs deleted (`api_montecarlo.csv`,
  `asynchronous_persistence_index.csv` removed from derived, tables, and the package);
  `spread_montecarlo.csv` added; Supplement S4 now reports the same statistic as §3.3.
  Venus dynamo row kept in persistence_spectrum.csv + Fig. 4, drawn grey-dashed
  "inferred, not dated", excluded from spread.
- **Energy driver:** `dom_driver` column added to energy_architecture.csv (was missing;
  the stale packaged copy with `dom=stellar` for all 8 bodies is replaced by the canonical
  derived file). Fig. 6 right panel + caption now say "dominant circulation-driving energy
  source". §3.6 claim calibrated ("more informative in this pilot" not "organizes better").

## Manuscript-side checks
- All key figures/docx/pdf regenerated this run; highlights + cover letter carry no stale
  numbers (age/mass rhos now f-strings; coverage dynamic).
- Data availability statement verified truthful: bougtoir/planetary_circulation is PUBLIC,
  populated, byte-identical to canonical tree at audit time (Issue 4 → PASS). NOTE: public
  sync must be re-run after this revision lands (see readiness report).
- No "first" claims; no index claims; habitability paragraph remains Discussion-only.
