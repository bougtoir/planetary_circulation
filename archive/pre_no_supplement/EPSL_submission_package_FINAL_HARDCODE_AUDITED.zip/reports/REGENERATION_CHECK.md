# REGENERATION CHECK (one controlled test)
Date: 2026-10-17 (UTC).

## Procedure
1. Snapshot `data/processed/`, `analysis/derived/`, `manuscript/` to /tmp.
2. Rerun the full pipeline once:
   `build_data.py → derive_matrices.py → analyze.py → figures_1_5_6.py → build_manuscript.py`
3. Compare.

## Result
- `data/processed/` — **byte-identical** on every file (diff -r clean).
- `analysis/derived/` — **byte-identical** on every file (diff -r clean; MC seeded, deterministic).
- `manuscript/` docx — zip member payload bytes identical; only zip-container metadata
  (entry timestamps) differs between the two writes, as expected. Extracted paragraph/table
  text identical. `highlights.txt` byte-identical.

## Verdict
PASS — one clean rerun reproduces all submission-facing outputs with no numeric drift and
no manual intervention. The pipeline is deterministic (PCA/MC seeded via
`np.random.default_rng(7)`; LibreOffice PDF conversion deterministic per docx).
